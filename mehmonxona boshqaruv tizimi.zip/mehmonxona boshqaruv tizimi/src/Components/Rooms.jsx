import React from "react";
import RoomsContainer from "./RoomsContainer";
const Rooms = () => {
  return (
    <div>
      <RoomsContainer />
    </div>
  );
};

export default Rooms;
